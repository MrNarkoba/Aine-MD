const { groupproto } = require('./GroupProtocol')

module.exports = groupproto